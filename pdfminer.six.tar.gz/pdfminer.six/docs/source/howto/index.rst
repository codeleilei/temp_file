.. _howto:

How-to guides
*************

How-to guides help you to solve specific problems with pdfminer.six.

.. toctree::
    :maxdepth: 1

    images
