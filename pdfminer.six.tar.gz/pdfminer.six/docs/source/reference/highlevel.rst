.. _api_highlevel:

High-level functions API
************************

.. _api_extract_text:

extract_text
============

.. currentmodule:: pdfminer.high_level
.. autofunction:: extract_text


.. _api_extract_text_to_fp:

extract_text_to_fp
==================

.. currentmodule:: pdfminer.high_level
.. autofunction:: extract_text_to_fp


extract_pages
=============

.. currentmodule:: pdfminer.high_level
.. autofunction:: extract_pages