.. _api_composable:

Composable API
**************

.. _api_laparams:

LAParams
========

.. currentmodule:: pdfminer.layout
.. autoclass:: LAParams

Todo:
=====

- `PDFDevice`
    - `TextConverter`
    - `PDFPageAggregator`
- `PDFPageInterpreter`