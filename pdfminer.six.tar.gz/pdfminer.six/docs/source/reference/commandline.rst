.. _api_commandline:


Command-line API
****************

.. _api_pdf2txt:

pdf2txt.py
==========

.. argparse::
    :module: tools.pdf2txt
    :func: maketheparser
    :prog: python tools/pdf2txt.py

.. _api_dumppdf:

dumppdf.py
==========

.. argparse::
    :module: tools.dumppdf
    :func: create_parser
    :prog: python tools/dumppdf.py
